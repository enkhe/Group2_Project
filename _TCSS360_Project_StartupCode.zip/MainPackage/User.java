package MainPackage;

import UI.*;

public interface User {
	public void Login();
	public void Register();
}