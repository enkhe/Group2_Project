package MainPackage;

import UI.*;

public class SubProgramChair extends RegisteredUser {
	private int userID;
	
	public void AssignReviewer() {
		
	}
	
	public void SubmitRecommendation() {
		
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}
}
