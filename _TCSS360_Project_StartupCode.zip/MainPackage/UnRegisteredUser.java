package MainPackage;

public class UnRegisteredUser implements User {

	@Override
	public void Login() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Register() {
		// TODO Auto-generated method stub
		
	}

	
}
