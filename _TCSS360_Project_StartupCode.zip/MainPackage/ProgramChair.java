package MainPackage;

import UI.*;

public class ProgramChair  extends RegisteredUser {
	
	private int userID;
	
	public void ChangeAcceptance() {
		
	}
	
	public void ViewPCAssignment() {
		
		
	}
	
	public void AssignSubProgramChair() {
		
		
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}
	
	
	
}
