package Test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class BusinessRulesTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	/**
	 * BR1. For each conference, only one user is the Program Chair.
	 */
	@Test
	public void testBR1() {
		fail("Not yet implemented");
		
	}
	/**
	 * BR2. A user becomes an Author only by submitting a manuscript.
	 */
	@Test
	public void testBR2() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR3. A user can take on more than one role for a given conference.
	 */
	@Test
	public void testBR3() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR4. An Author cannot review his or her own paper.
	 */
	@Test
	public void testBR4() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR5. A Subprogram Chair cannot be designated for a paper that he or she authored.
	 */
	@Test
	public void testBR5() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR6. A Reviewer cannot review a paper that he or she authored.
	 */
	@Test
	public void testBR6() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR7. A Reviewer can only access those manuscripts assigned to him or her.
	 */
	@Test
	public void testBR7() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR8. A Reviewer can only access the reviews that he or she submits.
	 */
	@Test
	public void testBR8() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR9. An Author can only access his or her submitted manuscripts and reviews for these manuscripts.
	 */
	@Test
	public void testBR9() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR10. A Reviewer can be assigned to review a maximum of 4 papers to review for any conference.
	 */
	@Test
	public void testBR10() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR11. A Subprogram Chair can be designated no more than 4 papers for any conference.
	 */
	@Test
	public void testBR11() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR12. Authors can only access reviews after the program chair has made a decision.
	 */
	@Test
	public void testBR12() {
		fail("Not yet implemented");
		
		
	}
	
	/**
	 * BR13. All paper submissions must be made on or before the submission deadline.
	 */
	@Test
	public void testBR13() {
		fail("Not yet implemented");
		
		
	}
	
}
